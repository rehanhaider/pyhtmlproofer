//Print hello world
console.log("hello world");
